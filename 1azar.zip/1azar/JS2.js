let count = 3;
if (count++ + 2 < 6 && count-- > 3) {
  console.log('First');
} else {
  console.log('Second');
}
console.log('final count =', count);