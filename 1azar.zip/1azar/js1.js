function getSeason(seasonNumber) {
  let seasonName;
  switch(seasonNumber) {
    case 1:
      seasonName = 'بهار';
      break;
    case 2:
      seasonName = 'تابستان';
      break;
    case 3:
      seasonName = 'پاییز';
      break;
    case 4:
      seasonName = 'زمستان';
      break;
    default:
      seasonName = 'شماره فصل نامعتبر ';
  }
  return seasonName;
}


console.log(getSeason(1)); 
console.log(getSeason(3)); 
console.log(getSeason(5)); 