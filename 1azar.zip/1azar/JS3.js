function shippingCost(totalPrice) {
    if (totalPrice < 100000) {
      return 20000; 
    } else if (totalPrice >= 100000 && totalPrice <= 200000) {
      return 10000; 
    } else { 
      return 0; 
    }
  }
  
  console.log(shippingCost(50000));   
  console.log(shippingCost(150000));  
  console.log(shippingCost(250000));  